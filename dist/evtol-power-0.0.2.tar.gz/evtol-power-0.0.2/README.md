# eVTOL Power and Range Estimation Model
by Caleb Harris, Georgia Institute of Technology, 2022